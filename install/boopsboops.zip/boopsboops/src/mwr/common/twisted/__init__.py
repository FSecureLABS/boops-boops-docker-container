from mwr.common.twisted.stream_receiver import StreamReceiver
