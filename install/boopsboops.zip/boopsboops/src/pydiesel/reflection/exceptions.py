
class ReflectionException(Exception):
    pass
    