
class InvalidMessageException(Exception):
    pass

class UnexpectedMessageException(Exception):
    pass
