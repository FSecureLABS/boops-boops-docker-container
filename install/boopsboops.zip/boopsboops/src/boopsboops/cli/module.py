from boopsboops.repoman import ModuleManager
import sys


ModuleManager().run(sys.argv[2::])
